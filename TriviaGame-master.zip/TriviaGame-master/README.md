# TriviaGame

### Overview

Created a Trivia game using JavaScript for the logic and jQuery to manipulate HTML. 10 questions randomly generated with countdown timer for answer.  App gives correct answer with gif/image after user guess.  After 10 questions, app will display score with the option to restart the game. 

### Technologies Utilized 

HTML5 CSS3 JavaScript JQuery

https://lindsfisch.github.io/TriviaGame/
